<?php

readline_add_history('<?=system("ls");');
readline_write_history('history.txt');
require 'history.txt';